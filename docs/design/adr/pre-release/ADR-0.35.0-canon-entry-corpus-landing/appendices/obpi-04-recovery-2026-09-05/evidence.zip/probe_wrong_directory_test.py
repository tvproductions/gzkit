"""Run one existing durability test with an in-memory wrong-directory mutation."""
import io
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import gzkit.content.ownership as ownership
from tests.content.test_ownership import TestWriteDeclarationAtomically

print("ownership_import:", ownership.__file__)
real_open = os.open
redirected = []
with tempfile.TemporaryDirectory() as unrelated:
    def wrong_directory(path, flags, *args, **kwargs):
        if flags == os.O_RDONLY and isinstance(path, (str, bytes, Path)) and Path(path).is_dir():
            redirected.append((str(path), unrelated))
            return real_open(unrelated, flags, *args, **kwargs)
        return real_open(path, flags, *args, **kwargs)

    output = io.StringIO()
    with patch.object(ownership.os, "open", side_effect=wrong_directory):
        result = unittest.TextTestRunner(stream=output, verbosity=2).run(
            unittest.TestSuite([
                TestWriteDeclarationAtomically(
                    "test_the_parent_directory_is_synced_so_the_rename_is_durable"
                )
            ])
        )
    print("redirected_directory_opens:", redirected)
    print("existing_test_survived_wrong_directory:", result.wasSuccessful())
    print(output.getvalue())
