"""Use existing fixtures to expose a silently incomplete recovery-residue sweep."""
from pathlib import Path
from unittest.mock import patch

import gzkit.commands.content.unown as unown
from tests.commands.test_content_unown import (
    CliRunner,
    _DECLARATION_PATH,
    _SEED_FLOOR,
    _crash_at_replace,
    _seed_declaration,
    _seed_surface,
    _unown,
)

print("unown_import:", unown.__file__)
runner = CliRunner()
with runner.isolated_filesystem():
    _seed_surface()
    _seed_declaration(alpha="corpus-owned", floor=_SEED_FLOOR)
    with patch.object(unown, "_append_event_once", side_effect=OSError(5, "injected append failure")):
        first = _unown(runner, attestor="g0", reason="probe")
    surface = Path("Doc.md")
    surface.write_bytes(surface.read_bytes() + b"editor addition\n")
    with _crash_at_replace("Doc.md.unowning-recovery"):
        extraction = _unown(runner, attestor="g0", reason="probe")
    residue = list(Path(".").glob(".Doc.md.unowning-recovery.*.tmp"))
    snapshot = _DECLARATION_PATH.parent / "Doc.md.json.journal.source"
    surface.write_bytes(snapshot.read_bytes())
    real_glob = Path.glob
    calls = []

    def unreadable_listing(path, pattern, *args, **kwargs):
        if pattern.startswith(".Doc.md.unowning-recovery."):
            calls.append(pattern)
            raise OSError(13, "injected directory enumeration failure")
        return real_glob(path, pattern, *args, **kwargs)

    with patch.object(Path, "glob", unreadable_listing):
        retry = _unown(runner, attestor="g0", reason="probe")
    print({
        "first_exit": first.exit_code,
        "extraction_exit": extraction.exit_code,
        "residue_before": len(residue),
        "listing_fault_calls": calls,
        "retry_exit": retry.exit_code,
        "residue_after": [path.name for path in residue if path.exists()],
        "journal_after": (_DECLARATION_PATH.parent / "Doc.md.json.journal").exists(),
        "snapshot_after": snapshot.exists(),
    })
    print("retry_output:", retry.output.strip())
