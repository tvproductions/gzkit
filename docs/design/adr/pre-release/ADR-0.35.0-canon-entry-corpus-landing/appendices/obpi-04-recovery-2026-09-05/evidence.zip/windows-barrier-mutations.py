"""Run bounded in-memory negative controls without changing the live source."""
import contextlib
import inspect
import io
import json
import sys
import unittest
from unittest import mock

sys.path.insert(0, '/Users/jeff/Documents/Code/gzkit/src')
sys.path.insert(0, '/Users/jeff/Documents/Code/gzkit')
from gzkit.content import ownership
from tests.content.test_ownership import TestWindowsDirectoryBarrier


def replaced_function(name, before, after):
    original = inspect.getsource(getattr(ownership, name))
    if before not in original:
        raise RuntimeError(f'Mutation target missing: {name}')
    modified = original.replace(before, after, 1)
    namespace = {}
    exec(compile(modified, f'<mutation:{name}>', 'exec'), ownership.__dict__, namespace)
    return namespace[name]


pending_source = inspect.getsource(ownership._commit_windows_directory)
pending_start = pending_source.index("        if status == 0x103:")
pending_end = pending_source.index("        if status != 0:")
pending_original = pending_source[pending_start:pending_end]
pending_mutant = replaced_function(
    '_commit_windows_directory', pending_original,
    "        if status == 0x103:\n            status = 0\n",
)

controls = [
    ('windows_noop', 'commit_directory_entry', lambda directory: None,
     'test_unavailable_windows_barrier_refuses_instead_of_returning_success'),
    ('ignore_flush_status', '_commit_windows_directory',
     replaced_function('_commit_windows_directory', 'if status != 0:', 'if False:'),
     'test_flush_errors_and_warnings_refuse_and_close_the_owned_handle'),
    ('accept_pending_without_completion', '_commit_windows_directory', pending_mutant,
     'test_pending_flush_waits_then_checks_the_completion_status'),
    ('ignore_close_failure', '_commit_windows_directory',
     replaced_function('_commit_windows_directory', 'if not kernel32.CloseHandle(handle):',
                       'if not kernel32.CloseHandle(handle) and False:'),
     'test_close_failure_is_observable_even_after_a_completed_flush'),
    ('wrong_ntstatus_width', '_windows_directory_apis',
     replaced_function('_windows_directory_apis',
                       'ntdll.NtFlushBuffersFileEx.restype = ctypes.c_int32',
                       'ntdll.NtFlushBuffersFileEx.restype = ctypes.c_int64'),
     'test_native_abi_uses_windows_widths_and_pointer_alignment_on_every_host'),
    ('unknown_platform_noop', 'commit_directory_entry',
     replaced_function('commit_directory_entry',
                       'raise OSError(errno.ENOTSUP, "directory synchronization is unsupported", str(directory))',
                       'return'),
     'test_unknown_platform_has_no_successful_no_op'),
]
report = []
for name, symbol, mutation, test_name in controls:
    output = io.StringIO()
    with mock.patch.object(ownership, symbol, mutation), contextlib.redirect_stderr(output):
        result = unittest.TextTestRunner(stream=output).run(
            unittest.TestSuite([TestWindowsDirectoryBarrier(test_name)])
        )
    report.append({
        'mutation': name, 'tests_run': result.testsRun,
        'assertion_failures': len(result.failures), 'errors': len(result.errors),
        'killed_by_assertion': bool(result.failures) and not result.errors,
        'output': output.getvalue(),
    })
print(json.dumps(report, indent=2))
raise SystemExit(0 if all(item['killed_by_assertion'] for item in report) else 1)
