"""Bind explicit OBPI-04 mutations to the currently inspected source bytes."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path

UNOWN = "src/gzkit/commands/content/unown.py"
OWNERSHIP = "src/gzkit/content/ownership.py"
TESTS = "tests/commands/test_content_unown.py"
OWN_TESTS = "tests/content/test_ownership.py"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def build(root: Path) -> dict:
    cases = []

    def add(identifier, subject, function, before, after, test, *, path=UNOWN, kind="behavior"):
        data = (root / path).read_bytes()
        source = data.decode("utf-8")
        tree = ast.parse(source)
        functions = [
            node
            for node in ast.walk(tree)
            if isinstance(node, ast.FunctionDef) and node.name == function
        ]
        assert len(functions) == 1, (identifier, function, len(functions))
        scope = ast.get_source_segment(source, functions[0])
        assert scope.count(before) == 1, (identifier, function, before, scope.count(before))
        assert before != after
        test_file = OWN_TESTS if test.startswith("tests.content.") else TESTS
        test_name = test.rsplit(".", 1)[-1]
        test_tree = ast.parse((root / test_file).read_text())
        matches = [
            node
            for node in ast.walk(test_tree)
            if isinstance(node, ast.FunctionDef) and node.name == test_name
        ]
        assert len(matches) == 1, (identifier, test_name, len(matches))
        cases.append(
            {
                "id": identifier,
                "subject": subject,
                "kind": kind,
                "historical_label": identifier if identifier.startswith("G") else None,
                "historical_equivalence": "Reconstructed current witness; original patch/runner unavailable"
                if identifier.startswith("G")
                else None,
                "path": path,
                "function": function,
                "before": before,
                "after": after,
                "expected_scope_occurrences": 1,
                "source_sha256": sha(data),
                "tests": [test],
                "test_path": test_file,
                "test_sha256": sha((root / test_file).read_bytes()),
                "require_assertion_failure": True,
            }
        )

    def g(n, subject, function, before, after, test, **kwargs):
        add(f"G{n}", subject, function, before, after, test, **kwargs)

    def r(n, subject, function, before, after, test, **kwargs):
        add(f"R{n:02}", subject, function, before, after, test, **kwargs)

    round9 = "tests.commands.test_content_unown.TestContentUnownRound9."
    round8 = "tests.commands.test_content_unown.TestContentUnownRound8."
    fixed = "tests.commands.test_content_unown.TestWitnessSourceIsTheFixedDestination."
    g(
        1,
        "Fresh consumed snapshot identity",
        "content_unown_cmd",
        "if declaration.surface != target.surface:",
        "if False:",
        round9 + "test_a_snapshot_identity_mismatch_on_the_fresh_path_is_refused",
    )
    g(
        2,
        "Unlanded consumed snapshot identity",
        "_apply_unlanded_transition",
        'if on_disk.get("surface") != target.surface:',
        "if False:",
        round9 + "test_a_snapshot_identity_mismatch_on_the_unlanded_recovery_branch_is_refused",
    )
    g(
        3,
        "Landed consumed snapshot identity",
        "_refuse_incoherent_landed_state",
        'if landed.get("surface") != target.surface:',
        "if False:",
        round9 + "test_a_snapshot_identity_mismatch_on_the_landed_recovery_branch_is_refused",
    )
    g(
        4,
        "Witness-source identity",
        "_checked_landed_snapshot",
        'if landed.get("surface") != target.surface:',
        "if False:",
        fixed + "test_a_foreign_identity_at_the_destination_is_refused",
    )
    g(
        5,
        "Witness-source transition equality",
        "_checked_landed_snapshot",
        "if divergent:",
        "if False:",
        fixed + "test_a_destination_that_is_not_the_expected_transition_is_refused",
    )
    g(
        6,
        "Entry different-file refusal",
        "_resolve_target_or_exit",
        "elif not _is_same_file(requested_path, declared_path):",
        "elif False:",
        round9 + "test_a_request_naming_a_different_file_than_the_declaration_is_refused",
    )
    g(
        7,
        "Missing requested file has truthful diagnosis",
        "_resolve_target_or_exit",
        "if not requested_path.exists():",
        "if False:",
        round9 + "test_a_request_naming_a_surface_that_does_not_exist_says_so",
        kind="diagnostic",
    )
    g(
        8,
        "Existing unreadable declaration propagates error",
        "_declared_surface",
        "if path.exists():",
        "if False:",
        round9 + "test_an_unreadable_existing_declaration_fails_closed_not_open",
    )
    g(
        9,
        "Journal identity bound to fixed target",
        "_journal_record_or_refuse",
        'if record["surface"] != target.surface:',
        "if False:",
        round9 + "test_a_journal_naming_a_second_spelling_of_the_surface_is_refused",
    )
    g(
        10,
        "Precommit raw-byte digest recheck",
        "content_unown_cmd",
        '_refuse_surface_changed_under_us(\n            target.surface_path, surface, section, record["surface_digest"]\n        )',
        "pass",
        round9 + "test_a_line_ending_conversion_between_measurement_and_commit_is_refused",
    )
    g(
        11,
        "Fresh finalization source binding",
        "_commit_transition",
        "_refuse_clean_success_on_a_moved_surface(target, record, committed_now=True)",
        "pass",
        "tests.commands.test_content_unown.TestContentUnownBindsTheSurfaceToTheTransaction.test_an_edit_between_the_check_and_the_commit_is_not_reported_as_success",
    )
    g(
        12,
        "Replay finalization source binding",
        "_replay_pending_transition",
        "_refuse_clean_success_on_a_moved_surface(target, record, committed_now=not settled)",
        "pass",
        round8 + "test_replay_finalization_also_verifies_the_journalled_surface",
    )
    g(
        13,
        "Alias canonicalization",
        "_resolve_target_or_exit",
        "return _target_for(root, declared)",
        "return _target_for(root, surface)",
        round9 + "test_a_second_spelling_of_the_surface_witnesses_the_declared_identity",
    )
    g(
        14,
        "Identity next step must not prescribe declaration hand-edit",
        "_refuse_surface_identity",
        '\'--attestor "<your name>" --reason "<why>"`.\'',
        '\'--attestor "<your name>" --reason "<why>"`, or repair the declaration.\'',
        round9 + "test_the_next_step_never_prescribes_editing_the_declaration",
        kind="diagnostic",
    )
    g(
        15,
        "Unreadable replay declaration is not absent",
        "_on_disk_declaration_or_refuse",
        "if not target.declaration_path.exists():",
        "if True:",
        round9 + "test_an_unreadable_declaration_during_replay_says_so",
        kind="diagnostic",
    )
    g(
        16,
        "Identity refusal exit matches journal retention",
        "_refuse_foreign_declaration_snapshot",
        "exit_code = 2 if journal_retained else 1",
        "exit_code = 2",
        round9 + "test_a_snapshot_identity_mismatch_on_the_fresh_path_is_refused",
        kind="diagnostic",
    )
    g(
        17,
        "Recovery witness test has a nonvacuous fixture",
        "_replay_pending_transition",
        "_append_witness_or_exit(root, target, record)",
        "pass",
        round8 + "test_recovering_a_different_section_never_claims_nothing_written",
        kind="fixture-sensitivity",
    )
    g(
        18,
        "Forged-journal advice must not prescribe hand-edit",
        "_refuse_forged_journal",
        '"  Do NOT delete the journal and do NOT hand-edit the ownership "',
        '"  Reconcile the declaration by hand. Do NOT delete the journal and do NOT hand-edit the ownership "',
        round9 + "test_the_forged_journal_next_step_never_prescribes_a_hand_edit",
        kind="diagnostic",
    )

    command = "tests.commands.test_content_unown."
    writer = "tests.content.test_ownership.TestWriteDeclarationAtomically."
    r(
        1,
        "State D still owes source reconciliation",
        "_replay_pending_transition",
        "_refuse_clean_success_on_a_moved_surface(target, record, committed_now=not settled)",
        "if not settled:\n        _refuse_clean_success_on_a_moved_surface(target, record, committed_now=not settled)",
        command
        + "TestRecoveryProtocolStateDPlusE.test_repeated_retries_never_erode_the_recovery_material",
    )
    r(
        2,
        "State B repeats declaration durability before witness",
        "_replay_pending_transition",
        "_reestablish_landed_declaration_durability(target)",
        "pass",
        command
        + "TestRecoveryProtocolStateB.test_landed_recovery_retries_the_barrier_and_refuses_while_it_fails",
    )
    r(
        3,
        "Journal removal failure retains dependent files",
        "_clear_recovery_state",
        "if failure is not None:",
        "if False:",
        command
        + "TestRecoveryCleanupIsItsOwnObligation.test_a_failed_journal_removal_retains_its_dependents_and_reports_the_fault",
    )
    r(
        4,
        "Absent-on-entry journal boundary precedes reuse",
        "_establish_recovery_boundary",
        "_establish_durable_journal_absence(target, removed_by_this_run=False)",
        "pass",
        command
        + "TestJournalAbsenceIsMadeDurableBeforeDependentsMove.test_a_failed_barrier_on_entry_preserves_the_orphan_and_refuses",
    )
    r(
        5,
        "Journal unlink barrier precedes dependent deletion",
        "_clear_recovery_state",
        "_establish_durable_journal_absence(target, removed_by_this_run=True)",
        "pass",
        command
        + "TestJournalAbsenceIsMadeDurableBeforeDependentsMove.test_a_failed_barrier_after_the_journal_removal_preserves_its_dependents",
    )
    r(
        6,
        "Unavailable barrier does not license success",
        "_establish_durable_journal_absence",
        "except OSError as exc:\n        if removed_by_this_run:",
        "except OSError as exc:\n        if exc.errno in BARRIER_UNSUPPORTED_ERRNOS:\n            return\n        if removed_by_this_run:",
        command
        + "TestUnavailableBarrierPreservesRecoveryMaterial.test_unavailable_barrier_after_journal_unlink_preserves_dependents",
    )
    r(
        7,
        "Actual filesystem enumeration failures are not an empty sweep",
        "_staging_residue",
        "path.parent.iterdir()",
        'path.parent.glob("*")',
        command
        + "TestRecoveryStagingInspectionFailures.test_extraction_listing_failure_is_reported_on_retries_then_heals",
    )
    r(
        8,
        "Unknown orphan family cannot exempt current cleanup",
        "_report_recovery_inspection_failure",
        "if after_completion:\n        sys.exit(2)",
        "if False:\n        sys.exit(2)",
        command
        + "TestRecoveryStagingInspectionFailures.test_unknown_orphan_family_cannot_exempt_new_transaction_cleanup",
    )
    r(
        9,
        "Directory barrier addresses actual destination parent",
        "write_bytes_atomically",
        "commit_directory_entry(path.parent)",
        "commit_directory_entry(path.parent.parent)",
        writer + "test_the_parent_directory_is_synced_so_the_rename_is_durable",
        path=OWNERSHIP,
    )
    r(
        10,
        "File bytes are synced before replacement",
        "write_bytes_atomically",
        "os.fsync(handle.fileno())",
        "pass",
        writer + "test_the_parent_directory_is_synced_so_the_rename_is_durable",
        path=OWNERSHIP,
    )
    r(
        11,
        "Journal-absent retry sweeps recovery residue",
        "_establish_recovery_boundary",
        "return _sweep_recovery_residue(target, after_completion=False)",
        "return frozenset()",
        command
        + "TestRecoveryCleanupIsItsOwnObligation.test_a_retry_sweeps_residue_left_after_the_journal_is_already_gone",
    )
    r(
        12,
        "Surface metacharacters remain literal during cleanup",
        "_staging_residue",
        'return sorted(\n        candidate\n        for candidate in path.parent.iterdir()\n        if candidate.name.startswith(prefix) and candidate.name.endswith(".tmp")\n    )',
        'return sorted(path.parent.glob(f"{prefix}*.tmp"))',
        command
        + "TestStagingResidueGlobIsLiteral.test_a_metacharacter_in_the_surface_name_is_matched_literally",
    )
    r(
        13,
        "Failed extraction never licenses verified restore sequence",
        "_extract_retained_source",
        '"do NOT hand-edit the ownership declaration.",\n            False,',
        '"do NOT hand-edit the ownership declaration.",\n            True,',
        command
        + "TestFailedExtractionDoesNotClaimAbsence.test_existing_and_replaced_extracts_remain_unconfirmed_after_write_fault",
        kind="diagnostic",
    )
    r(
        14,
        "Unreadable pending source identifies retained unverified material",
        "_read_transaction_surface_or_exit",
        "if target.journal_path.exists():",
        "if False:",
        command
        + "TestUnreadablePendingSourceNamesRecoveryMaterial.test_unreadable_and_non_utf8_source_retries_name_unverified_retention",
        kind="diagnostic",
    )
    r(
        15,
        "Legacy witnessed journal still validates live source",
        "_replay_pending_transition",
        'if not settled or record.get("surface_digest") is None:',
        "if not settled:",
        command
        + "TestLegacyJournalStillObservesTheLiveSurface.test_a_restructured_surface_is_still_refused_under_a_legacy_journal",
    )
    r(
        16,
        "Reused snapshot is this transaction's cleanup obligation",
        "_sweep_recovery_residue",
        "path.as_posix() for path, _ in failures if path != target.journal_source_path",
        "path.as_posix() for path, _ in failures",
        command
        + "TestOrphanResidueWarnsAndPermitsFreshWork.test_this_transactions_own_cleanup_failure_is_still_non_success",
    )
    r(
        17,
        "Extract failure does not falsely claim absent file",
        "_extract_retained_source",
        '"state and durability are unconfirmed. Fix the storage fault under "',
        '"state: no extract exists. Fix the storage fault under "',
        command
        + "TestFailedExtractionDoesNotClaimAbsence.test_existing_and_replaced_extracts_remain_unconfirmed_after_write_fault",
        kind="diagnostic",
    )
    r(
        18,
        "Journal storage fault is not classified as forgery",
        "_journal_record_or_refuse",
        "_refuse_unreadable_journal(target, exc)",
        "_refuse_forged_journal(target, str(exc))",
        command
        + "TestJournalStorageFaultIsNotForgery.test_an_unreadable_existing_journal_names_the_storage_fault",
        kind="diagnostic",
    )
    return {
        "schema_version": 1,
        "obpi": "OBPI-0.35.0-04-section-ownership-and-ratchet",
        "source_root": str(root.resolve()),
        "cases": cases,
        "limitations": [
            "G1–G18 reconstruct current witnesses from the historical labels; the original runner was lost. These are not a replay of its exact historical edits.",
            "No historical G19–G22 targets are asserted or invented. R01 onward are newly named current mutations.",
            "Named tests prove sensitivity to these exact changes, not exhaustive fault coverage or power-loss behavior.",
            "Diagnostic and fixture-sensitivity mutations are explicitly distinguished from state-preservation mutations.",
            "Ledger durability/atomicity GHI #952/#953 and arbitrary coherent .gzkit tampering remain accepted boundaries.",
            "Windows-specific mutation/evidence remains pending final native implementation and actual Windows verification.",
        ],
        "windows_status": "PENDING",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest = build(args.root)
    args.output.write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"Bound {len(manifest['cases'])} explicit mutations to current source and test hashes.")
