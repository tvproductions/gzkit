"""Finite OBPI04 diagnostic acceptance cases; writes only isolated temp files.

OS exceptions and explicitly arranged retry states are fault injection, not
power-loss experiments. See recovery-contract-runner.md for scope and commands.
"""

from __future__ import annotations

import argparse
import contextlib
import io
import json
import os
import stat
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import gzkit.commands.content.unown as unown
import gzkit.content.ownership as ownership
from tests.commands.test_content_unown import (
    CliRunner,
    _DECLARATION_PATH,
    _SEED_FLOOR,
    _crash_at_replace,
    _ledger_events,
    _seed_declaration,
    _seed_surface,
    _unown,
)

JOURNAL = _DECLARATION_PATH.with_name("Doc.md.json.journal")
SOURCE = _DECLARATION_PATH.with_name("Doc.md.json.journal.source")
EXTRACT = Path("Doc.md.unowning-recovery")
OBSERVATIONS: list[dict] = []
BARRIER_ERROR = "diagnostic injected journal-absence barrier EIO"
ENUMERATION_ERROR = "diagnostic injected extraction enumeration EACCES"


def identity(info):
    return info.st_dev, info.st_ino


def invoke(runner):
    return _unown(runner, attestor="g0", reason="standalone recovery contract diagnostic")


@unittest.skipUnless(os.name == "posix", "directory-fsync contract is POSIX-specific")
class TestRecoveryContract(unittest.TestCase):
    def setUp(self):
        self.runner = CliRunner()

    def settled_with_material(self):
        """Arrange the state immediately before cleanup using real CLI writes."""
        _seed_surface()
        _seed_declaration(alpha="corpus-owned", floor=_SEED_FLOOR)
        with patch.object(unown, "_clear_recovery_state", lambda target, **kwargs: None):
            first = invoke(self.runner)
        self.assertEqual(first.exit_code, 0, first.output)
        self.assertTrue(JOURNAL.exists())
        self.assertEqual(SOURCE.read_bytes(), Path("Doc.md").read_bytes())
        return _DECLARATION_PATH.read_bytes(), _ledger_events(), SOURCE.read_bytes()

    def assert_settled_unchanged(self, declaration, ledger, source):
        self.assertEqual(_DECLARATION_PATH.read_bytes(), declaration)
        self.assertEqual(_ledger_events(), ledger, "cleanup must not add another attestation")
        self.assertEqual(Path("Doc.md").read_bytes(), source)
        loaded = ownership.load_declaration(
            _DECLARATION_PATH, Path("Doc.md").read_bytes().decode("utf-8"), Path(".")
        )
        self.assertEqual(loaded.sections["alpha-section"], "unowned")

    def writer_observation(self, *, redirect_parent=False):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            parent = root / "actual-parent"
            unrelated = root / "unrelated-directory"
            parent.mkdir()
            unrelated.mkdir()
            target = parent / "declaration.json"
            expected = identity(parent.stat())
            trace = []
            real_open, real_fsync, real_replace = os.open, os.fsync, os.replace

            def open_directory(path, flags, *args, **kwargs):
                if redirect_parent and Path(path) == parent and flags == os.O_RDONLY:
                    return real_open(unrelated, flags, *args, **kwargs)
                return real_open(path, flags, *args, **kwargs)

            def fsync(fd):
                info = os.fstat(fd)
                kind = "directory" if stat.S_ISDIR(info.st_mode) else "file"
                real_fsync(fd)
                trace.append((kind, identity(info)))

            def replace(source, destination, *args, **kwargs):
                result = real_replace(source, destination, *args, **kwargs)
                if Path(destination) == target:
                    trace.append(("replace", identity(target.stat())))
                return result

            with (
                patch.object(os, "open", open_directory),
                patch.object(os, "fsync", fsync),
                patch.object(os, "replace", replace),
            ):
                ownership.write_declaration_atomically(target, '{"floor": 83}\n')
            self.assertEqual(target.read_bytes(), b'{"floor": 83}\n')
            OBSERVATIONS.append({"case": self.id(), "trace": trace, "expected_parent": expected})
            return trace, expected

    def assert_writer_contract(self, trace, expected_parent):
        replacement = next(i for i, (kind, _) in enumerate(trace) if kind == "replace")
        self.assertTrue(any(kind == "file" for kind, _ in trace[:replacement]))
        self.assertIn(
            ("directory", expected_parent), trace[replacement + 1 :],
            "the actual destination parent must be synced after replacement",
        )

    def test_writer_syncs_actual_parent_after_replace(self):
        self.assert_writer_contract(*self.writer_observation())

    def test_writer_identity_assertion_rejects_wrong_directory_negative_control(self):
        trace, expected = self.writer_observation(redirect_parent=True)
        with self.assertRaisesRegex(AssertionError, "actual destination parent"):
            self.assert_writer_contract(trace, expected)

    @contextlib.contextmanager
    def trace_cleanup(self, *, fail_barrier=False):
        expected_parent = identity(JOURNAL.parent.stat())
        real_fsync, real_unlink = os.fsync, Path.unlink
        trace = []

        def fsync(fd):
            info = os.fstat(fd)
            if (
                stat.S_ISDIR(info.st_mode)
                and identity(info) == expected_parent
                and not JOURNAL.exists()
            ):
                if fail_barrier:
                    trace.append("journal-absence-barrier-failed")
                    raise OSError(5, BARRIER_ERROR)
                real_fsync(fd)
                trace.append("journal-absence-barrier-durable")
                return
            return real_fsync(fd)

        def unlink(path, *args, **kwargs):
            result = real_unlink(path, *args, **kwargs)
            if path.name == JOURNAL.name:
                trace.append("journal-unlinked")
            elif path.name in (SOURCE.name, EXTRACT.name):
                trace.append(f"dependent-unlinked:{path.name}")
            return result

        with patch.object(os, "fsync", fsync), patch.object(Path, "unlink", unlink):
            yield trace

    def ordering_case(self, *, journal_absent):
        with self.runner.isolated_filesystem():
            declaration, ledger, source = self.settled_with_material()
            if journal_absent:
                # Explicit state fixture: deletion visible, durability not established.
                JOURNAL.unlink()
            with self.trace_cleanup() as trace:
                result = invoke(self.runner)
            OBSERVATIONS.append({"case": self.id(), "trace": trace, "exit": result.exit_code})
            self.assert_settled_unchanged(declaration, ledger, source)
            self.assertFalse(SOURCE.exists())
            self.assertIn("journal-absence-barrier-durable", trace)
            barrier = trace.index("journal-absence-barrier-durable")
            if not journal_absent:
                self.assertLess(trace.index("journal-unlinked"), barrier)
            self.assertLess(barrier, trace.index(f"dependent-unlinked:{SOURCE.name}"))

    def test_journal_present_cleanup_barrier_precedes_dependents(self):
        self.ordering_case(journal_absent=False)

    def test_journal_absent_cleanup_barrier_precedes_dependents(self):
        self.ordering_case(journal_absent=True)

    def failed_barrier_case(self, *, journal_absent):
        with self.runner.isolated_filesystem():
            declaration, ledger, source = self.settled_with_material()
            if journal_absent:
                JOURNAL.unlink()
            attempts = []
            for retry in range(2):
                with self.trace_cleanup(fail_barrier=True) as trace:
                    result = invoke(self.runner)
                attempts.append({
                    "retry": retry, "exit": result.exit_code, "output": result.output,
                    "trace": list(trace), "journal_present": JOURNAL.exists(),
                    "snapshot_retained": SOURCE.exists() and SOURCE.read_bytes() == source,
                })
            healed = invoke(self.runner)
            OBSERVATIONS.append({"case": self.id(), "attempts": attempts, "healed_exit": healed.exit_code})
            self.assert_settled_unchanged(declaration, ledger, source)
            self.assertFalse(JOURNAL.exists())
            self.assertFalse(SOURCE.exists())
            for attempt in attempts:
                with self.subTest(retry=attempt["retry"]):
                    self.assertIn("journal-absence-barrier-failed", attempt["trace"])
                    self.assertNotEqual(attempt["exit"], 0, attempt["output"])
                    self.assertIn(BARRIER_ERROR, attempt["output"])
                    self.assertTrue(attempt["snapshot_retained"], "barrier failure must retain measured bytes")
                    self.assertFalse(any(item.startswith("dependent-unlinked:") for item in attempt["trace"]))

    def test_journal_present_barrier_failure_retries_absence_then_heals(self):
        self.failed_barrier_case(journal_absent=False)

    def test_journal_absent_barrier_failure_repeats_then_heals(self):
        self.failed_barrier_case(journal_absent=True)

    def test_real_extraction_staging_enumeration_fault_repeats_then_heals(self):
        with self.runner.isolated_filesystem():
            _seed_surface()
            _seed_declaration(alpha="corpus-owned", floor=_SEED_FLOOR)
            with patch.object(unown, "_append_event_once", side_effect=OSError(5, "injected append failure")):
                interrupted = invoke(self.runner)
            self.assertEqual(interrupted.exit_code, 2, interrupted.output)
            measured = SOURCE.read_bytes()
            Path("Doc.md").write_bytes(measured + b"editor addition\n")
            with _crash_at_replace(EXTRACT.name):
                extraction = invoke(self.runner)
            self.assertEqual(extraction.exit_code, 2, extraction.output)
            residue = list(Path(".").glob(".Doc.md.unowning-recovery.*.tmp"))
            self.assertEqual(len(residue), 1, "the real writer must produce the residue")
            self.assertEqual(residue[0].read_bytes(), measured)
            Path("Doc.md").write_bytes(measured)  # Operator deliberately restores measured bytes.
            root = Path.cwd().resolve()
            real_scandir, real_listdir = os.scandir, os.listdir
            calls = []

            def should_fail(path):
                return not isinstance(path, int) and Path(path).resolve() == root

            def scandir(path="."):
                if should_fail(path):
                    calls.append("scandir")
                    raise OSError(13, ENUMERATION_ERROR)
                return real_scandir(path)

            def listdir(path="."):
                if should_fail(path):
                    calls.append("listdir")
                    raise OSError(13, ENUMERATION_ERROR)
                return real_listdir(path)

            attempts = []
            for retry in range(2):
                prior_calls = len(calls)
                with (
                    patch.object(os, "scandir", scandir),
                    patch.object(os, "listdir", listdir),
                    # Python 3.13 binds this reference before os.scandir is
                    # patched. Keep Path.glob/iterdir real: glob's own error
                    # suppression is part of the behavior being exercised.
                    patch.object(Path._globber, "scandir", staticmethod(scandir)),
                ):
                    result = invoke(self.runner)
                attempts.append({
                    "retry": retry, "exit": result.exit_code, "output": result.output,
                    "enumeration_attempts": len(calls) - prior_calls,
                    "listing_apis_faulted": calls[prior_calls:],
                    "residue_retained": residue[0].exists(),
                })
            healed = invoke(self.runner)
            OBSERVATIONS.append({"case": self.id(), "attempts": attempts, "healed_exit": healed.exit_code})
            self.assertEqual(Path("Doc.md").read_bytes(), measured)
            self.assertFalse(residue[0].exists(), "healed retry must sweep the actual extraction residue")
            self.assertFalse(JOURNAL.exists())
            self.assertFalse(SOURCE.exists())
            events = [row for row in _ledger_events() if row["event"] == "section_ownership_unowned"]
            self.assertEqual(len(events), 1, "retries must witness this transition once")
            loaded = ownership.load_declaration(_DECLARATION_PATH, measured.decode("utf-8"), Path("."))
            self.assertEqual(loaded.sections["alpha-section"], "unowned")
            for attempt in attempts:
                with self.subTest(retry=attempt["retry"]):
                    self.assertGreater(attempt["enumeration_attempts"], 0)
                    self.assertTrue(attempt["residue_retained"])
                    self.assertIn(ENUMERATION_ERROR, attempt["output"], "enumeration failure cannot mean an empty sweep")
                    if attempt["retry"] == 0:
                        self.assertNotEqual(attempt["exit"], 0, "current-transaction cleanup is incomplete")


def run():
    parser = argparse.ArgumentParser()
    parser.add_argument("--expected-root", type=Path, required=True)
    parser.add_argument("--result-prefix", type=Path, default=Path(__file__).with_suffix(""))
    args = parser.parse_args()
    expected = args.expected_root.resolve()
    imports = {
        "unown": unown.__file__, "ownership": ownership.__file__,
        "fixture_module": sys.modules["tests.commands.test_content_unown"].__file__,
    }
    for name, location in imports.items():
        if not Path(location).resolve().is_relative_to(expected):
            raise RuntimeError(f"wrong {name} import: {location}; expected under {expected}")
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(TestRecoveryContract)
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    report = {
        "imports": imports, "tests_run": result.testsRun,
        "assertion_failures": [{"test": test.id(), "traceback": trace} for test, trace in result.failures],
        "setup_or_runtime_errors": [{"test": test.id(), "traceback": trace} for test, trace in result.errors],
        "skipped": [(test.id(), reason) for test, reason in result.skipped],
        "observations": OBSERVATIONS, "successful": result.wasSuccessful(),
        "scope": "OS fault injection and retry-state fixtures; not power-loss proof; ledger exceptions unchanged",
    }
    args.result_prefix.with_suffix(".json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    args.result_prefix.with_suffix(".log").write_text(stream.getvalue(), encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("imports", "tests_run", "successful")}, indent=2))
    print(stream.getvalue(), end="")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(run())
