"""Observe directory EINVAL behavior; no claim about a physical NFS host."""
import errno
import json
import os
import stat
from pathlib import Path
from unittest.mock import patch

import gzkit.commands.content.unown as unown
from tests.commands.test_content_unown import (
    CliRunner, _DECLARATION_PATH, _SEED_FLOOR, _ledger_events,
    _seed_declaration, _seed_surface, _unown,
)

runner = CliRunner()
journal = _DECLARATION_PATH.with_name("Doc.md.json.journal")
snapshot = _DECLARATION_PATH.with_name("Doc.md.json.journal.source")
real_fsync = os.fsync
results = []

for pending in (False, True):
    with runner.isolated_filesystem():
        _seed_surface()
        _seed_declaration(alpha="corpus-owned", floor=_SEED_FLOOR)
        if pending:
            with patch.object(unown, "_clear_recovery_state", lambda target, **kwargs: None):
                seeded = _unown(runner, attestor="g0", reason="diagnostic")
            assert seeded.exit_code == 0, seeded.output
            assert journal.exists() and snapshot.exists()
        before_declaration = _DECLARATION_PATH.read_bytes()
        before_ledger = _ledger_events()
        calls = []

        def fail_directory(fd):
            if stat.S_ISDIR(os.fstat(fd).st_mode):
                calls.append("directory-fsync-EINVAL")
                raise OSError(errno.EINVAL, "diagnostic directory sync unavailable")
            return real_fsync(fd)

        with patch.object(os, "fsync", fail_directory):
            result = _unown(runner, attestor="g0", reason="diagnostic")
        assert calls, "fault was not reached"
        results.append({
            "entry": "witnessed-transition-awaiting-cleanup" if pending else "fresh",
            "exit": result.exit_code,
            "fault_calls": len(calls),
            "journal_remains": journal.exists(),
            "snapshot_remains": snapshot.exists(),
            "declaration_unchanged": _DECLARATION_PATH.read_bytes() == before_declaration,
            "ledger_unchanged": _ledger_events() == before_ledger,
            "mandatory_boundary_disposition_holds": (
                result.exit_code != 0
                and (snapshot.exists() if pending else not snapshot.exists())
                and _DECLARATION_PATH.read_bytes() == before_declaration
                and _ledger_events() == before_ledger
            ),
            "output": result.output,
        })

report = {"import": unown.__file__, "observations": results}
Path(__file__).with_name("unsupported-barrier-observations.json").write_text(
    json.dumps(report, indent=2) + "\n", encoding="utf-8"
)
print(json.dumps(report, indent=2))
