"""Exercise pending recovery with an undecodable live source, without source edits."""

import json
from pathlib import Path
from unittest.mock import patch

import gzkit.commands.content.unown as unown
from gzkit.content.ownership import load_declaration
from tests.commands.common import CliRunner
from tests.commands.test_content_unown import (
    _DECLARATION_PATH,
    _ledger_events,
    _seed_declaration,
    _seed_surface,
    _unown,
)


def main():
    print("unown_import:", unown.__file__)
    runner = CliRunner()
    with runner.isolated_filesystem():
        _seed_surface()
        _seed_declaration()
        journal = _DECLARATION_PATH.with_name("Doc.md.json.journal")
        snapshot = journal.with_name(journal.name + ".source")
        with patch.object(unown, "_append_event_once", side_effect=OSError("atomic append fault")):
            first = _unown(runner, attestor="g0", reason="source recovery probe")
        assert first.exit_code != 0, first.output
        assert journal.is_file() and snapshot.is_file()
        retained = snapshot.read_bytes()
        newer = b"newer bytes that must be saved\xff\n"
        Path("Doc.md").write_bytes(newer)
        retries = []
        for _ in range(2):
            result = _unown(runner, attestor="g0", reason="source recovery probe")
            assert result.exit_code != 0, result.output
            assert snapshot.read_bytes() == retained
            assert journal.is_file()
            assert Path("Doc.md").read_bytes() == newer
            assert not [e for e in _ledger_events() if e["event"] == "section_ownership_unowned"]
            retries.append({"exit": result.exit_code, "output": result.output})
        # This is deliberate operator restoration, using only retained implementation bytes.
        Path("newer-edit.saved").write_bytes(Path("Doc.md").read_bytes())
        Path("Doc.md").write_bytes(snapshot.read_bytes())
        recovered = _unown(runner, attestor="g0", reason="source recovery probe")
        assert recovered.exit_code == 0, recovered.output
        declaration = load_declaration(
            _DECLARATION_PATH, Path("Doc.md").read_bytes().decode("utf-8"), Path(".")
        )
        events = [e for e in _ledger_events() if e["event"] == "section_ownership_unowned"]
        assert len(events) == 1
        assert declaration.sections["alpha-section"] == "unowned"
        assert Path("newer-edit.saved").read_bytes() == newer
        assert not journal.exists() and not snapshot.exists()
        print(json.dumps({"first_exit": first.exit_code, "invalid_source_retries": retries,
                          "recovered_exit": recovered.exit_code, "witnesses": len(events),
                          "reload": "ACCEPTED", "newer_bytes_preserved": True}, indent=2))


if __name__ == "__main__":
    main()
