r"""Observe one Windows directory-flush candidate; never claim crash durability.

Run on Windows: uv run --no-project python .\probe_windows_directory_barrier.py
Exit 0: candidate calls completed; 2: observed failure; 3: Windows not executed.

API references:
https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew
https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/ntifs/nf-ntifs-ntflushbuffersfileex
https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/wdm/ns-wdm-_io_status_block
"""

from __future__ import annotations

import ctypes
import json
import os
import platform
import sys
import tempfile
from pathlib import Path
from typing import Any

NTSTATUS = ctypes.c_int32
ULONG = ctypes.c_uint32
HANDLE = ctypes.c_void_p
STATUS_PENDING = 0x00000103
STATUS_SUCCESS = 0
INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value


class StatusOrPointer(ctypes.Union):
    """Model the pointer-aligned anonymous Windows status union."""

    _fields_ = [("Status", NTSTATUS), ("Pointer", ctypes.c_void_p)]


class IOStatusBlock(ctypes.Structure):
    """Match IO_STATUS_BLOCK without packing away its native alignment."""

    _anonymous_ = ("Result",)
    _fields_ = [("Result", StatusOrPointer), ("Information", ctypes.c_size_t)]


def status_hex(value: int) -> str:
    """Render a signed NTSTATUS as its familiar 32-bit hexadecimal value."""
    return f"0x{value & 0xFFFFFFFF:08X}"


def error_record(error: Exception) -> dict[str, Any]:
    """Keep numeric OS errors alongside their human-readable messages."""
    return {
        "type": type(error).__name__,
        "message": str(error),
        "errno": getattr(error, "errno", None),
        "winerror": getattr(error, "winerror", None),
    }


def bind_apis() -> tuple[Any, Any]:
    """Use WinDLL's Windows calling convention, including on 32-bit Python."""
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    ntdll = ctypes.WinDLL("ntdll")
    kernel32.CreateFileW.argtypes = [
        ctypes.c_wchar_p,
        ULONG,
        ULONG,
        ctypes.c_void_p,
        ULONG,
        ULONG,
        HANDLE,
    ]
    kernel32.CreateFileW.restype = HANDLE
    kernel32.CloseHandle.argtypes = [HANDLE]
    kernel32.CloseHandle.restype = ctypes.c_int32
    kernel32.WaitForSingleObject.argtypes = [HANDLE, ULONG]
    kernel32.WaitForSingleObject.restype = ULONG
    ntdll.NtFlushBuffersFileEx.argtypes = [
        HANDLE,
        ULONG,
        ctypes.c_void_p,
        ULONG,
        ctypes.POINTER(IOStatusBlock),
    ]
    ntdll.NtFlushBuffersFileEx.restype = NTSTATUS
    ntdll.RtlNtStatusToDosError.argtypes = [NTSTATUS]
    ntdll.RtlNtStatusToDosError.restype = ULONG
    return kernel32, ntdll


def directory_barrier(directory: Path, phase: str, kernel32: Any, ntdll: Any) -> dict[str, Any]:
    """Observe one native directory flush and close its owned handle."""
    result: dict[str, Any] = {
        "operation": "directory_barrier",
        "phase": phase,
        "path": str(directory),
        "desired_access": "GENERIC_WRITE",
        "share_mode": ["FILE_SHARE_READ", "FILE_SHARE_WRITE", "FILE_SHARE_DELETE"],
        "creation_disposition": "OPEN_EXISTING",
        "flags": ["FILE_FLAG_BACKUP_SEMANTICS"],
        "overlapped": False,
        "flush_flags": 0,
        "ok": False,
    }
    handle = kernel32.CreateFileW(str(directory), 0x40000000, 0x00000007, None, 3, 0x02000000, None)
    if handle is None or handle == INVALID_HANDLE_VALUE:
        result["create_file_error"] = error_record(ctypes.WinError(ctypes.get_last_error()))
        return result
    result["create_file_succeeded"] = True
    # A non-success sentinel exposes an IO_STATUS_BLOCK the API never updated.
    iosb = IOStatusBlock()
    iosb.Status = NTSTATUS(0xC0000001).value
    try:
        returned = int(ntdll.NtFlushBuffersFileEx(handle, 0, None, 0, ctypes.byref(iosb)))
        result["returned_ntstatus"] = status_hex(returned)
        if returned == STATUS_PENDING:
            # Unexpected for this synchronous operation/handle. Do not mistake
            # the informational STATUS_PENDING value for completed success.
            # Wait before allowing the caller-owned IO_STATUS_BLOCK to die.
            wait_result = int(kernel32.WaitForSingleObject(handle, 0xFFFFFFFF))
            result["wait_result"] = status_hex(wait_result)
            if wait_result != 0:  # WAIT_OBJECT_0
                result["wait_error"] = error_record(ctypes.WinError(ctypes.get_last_error()))
                result["pending_completion_unproved"] = True
                # Keep the buffer alive for this short-lived probe process.
                _pending_buffers.append(iosb)
                return result
            final_status = int(iosb.Status)
            result["final_status_source"] = "IO_STATUS_BLOCK after wait"
        else:
            # Microsoft says the return code, not IO_STATUS_BLOCK, is
            # authoritative when the return is other than STATUS_PENDING.
            final_status = returned
            result["final_status_source"] = "syscall return"
        result["io_status_block_status"] = status_hex(int(iosb.Status))
        result["io_status_block_information"] = int(iosb.Information)
        result["final_ntstatus"] = status_hex(final_status)
        result["ok"] = final_status == STATUS_SUCCESS
        if not result["ok"]:
            winerror = int(ntdll.RtlNtStatusToDosError(final_status))
            result["flush_error"] = error_record(ctypes.WinError(winerror))
    finally:
        if not kernel32.CloseHandle(handle):
            result["close_error"] = error_record(ctypes.WinError(ctypes.get_last_error()))
            result["ok"] = False
    return result


_pending_buffers: list[IOStatusBlock] = []


def main() -> int:
    """Print one JSON capability report and an unambiguous process result."""
    pointer_size = ctypes.sizeof(ctypes.c_void_p)
    report: dict[str, Any] = {
        "probe": "CreateFileW directory + NtFlushBuffersFileEx flags=0",
        "platform": platform.platform(),
        "os_name": os.name,
        "python": sys.version,
        "pointer_bits": 8 * pointer_size,
        "abi": {
            "ntstatus_bytes": ctypes.sizeof(NTSTATUS),
            "ulong_bytes": ctypes.sizeof(ULONG),
            "io_status_block_bytes": ctypes.sizeof(IOStatusBlock),
            "information_offset": IOStatusBlock.Information.offset,
        },
        "windows_executed": False,
        "durability_proven": False,
        "limitations": [
            "Capability observation in one process-owned temporary directory only.",
            "No crash, power-loss, storage-cache, or filesystem-wide durability proof.",
            "The exact CreateFileW/native-flush combination is not explicitly "
            "promised by the cited documentation.",
            "No privilege elevation, volume handle, alternate API, or fallback is attempted.",
        ],
        "operations": [],
    }
    if os.name != "nt":
        report["outcome"] = "unexecuted: Windows is required"
        print(json.dumps(report, indent=2))
        return 3
    report["windows_executed"] = True
    exit_code = 2
    try:
        if (ctypes.sizeof(NTSTATUS), ctypes.sizeof(ULONG)) != (4, 4):
            raise RuntimeError("Windows NTSTATUS/ULONG ABI mismatch")
        if ctypes.sizeof(IOStatusBlock) != 2 * pointer_size:
            raise RuntimeError("Windows IO_STATUS_BLOCK size mismatch")
        if IOStatusBlock.Information.offset != pointer_size:
            raise RuntimeError("Windows IO_STATUS_BLOCK Information offset mismatch")
        kernel32, ntdll = bind_apis()
        with tempfile.TemporaryDirectory(prefix="gzkit-directory-barrier-") as name:
            directory = Path(name).resolve()
            report["directory"] = str(directory)
            source = directory / "child.pending"
            renamed = directory / "child.committed"
            content = b"gzkit Windows directory barrier capability probe\n"
            with source.open("xb") as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            report["operations"].append({"operation": "child_write_and_file_fsync", "ok": True})
            source.replace(renamed)
            report["operations"].append(
                {
                    "operation": "rename",
                    "ok": renamed.read_bytes() == content and not source.exists(),
                }
            )
            report["operations"].append(
                directory_barrier(directory, "after_rename", kernel32, ntdll)
            )
            renamed.unlink()
            report["operations"].append({"operation": "unlink", "ok": not renamed.exists()})
            report["operations"].append(
                directory_barrier(directory, "after_unlink", kernel32, ntdll)
            )
            report["remaining_children"] = [child.name for child in directory.iterdir()]
            if (
                all(item["ok"] for item in report["operations"])
                and not report["remaining_children"]
            ):
                report["outcome"] = "candidate capability observed; durability not proven"
                exit_code = 0
            else:
                report["outcome"] = "candidate capability failed"
        report["temporary_directory_removed"] = not directory.exists()
    except (OSError, AttributeError, RuntimeError) as error:
        exit_code = 2
        report["outcome"] = "probe failed"
        report["error"] = error_record(error)
    print(json.dumps(report, indent=2))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
