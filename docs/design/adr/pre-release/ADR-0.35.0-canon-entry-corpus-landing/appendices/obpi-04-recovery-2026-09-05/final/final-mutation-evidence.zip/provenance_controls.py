"""Positive method/helper witnesses and negative setup/teardown/import controls."""
import importlib.util,json,sys
from pathlib import Path
b=Path('/private/tmp/gzkit-obpi04-final-mutations')
spec=importlib.util.spec_from_file_location('runner',b/'run_sweep-v2.py'); runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
controls={
'method_assertion': ('', '    def test_probe(self):\n        self.assertEqual(1,2)\n', True),
'helper_subtest_assertion': ('', '    def helper(self):\n        with self.subTest(case=1):\n            self.assertEqual(1,2)\n    def test_probe(self):\n        self.helper()\n',True),
'setup_assertion': ('', '    def setUp(self):\n        self.assertEqual(1,2)\n    def test_probe(self):\n        pass\n',False),
'setup_subtest_assertion': ('', '    def setUp(self):\n        with self.subTest(case=1):\n            self.assertEqual(1,2)\n    def test_probe(self):\n        pass\n',False),
'setup_error': ('', '    def setUp(self):\n        raise RuntimeError("setup")\n    def test_probe(self):\n        pass\n',False),
'teardown_assertion': ('', '    def tearDown(self):\n        self.assertEqual(1,2)\n    def test_probe(self):\n        pass\n',False),
'import_error': ('raise RuntimeError("import")\n', '    def test_probe(self):\n        pass\n',False),
'origin_escape': ('from pathlib import Path\n__file__ = str(Path(__file__).resolve().parents[2] / "outside.py")\n', '    def test_probe(self):\n        self.assertEqual(1,2)\n',False),
}
report=[]
for name,(source,test,expected) in controls.items():
    p=b/'provenance-controls-v2'/name;repo=p/'work'
    (repo/'gzkit').mkdir(parents=True);(repo/'tests').mkdir()
    (repo/'gzkit/__init__.py').write_text('',encoding='utf-8');(repo/'tests/__init__.py').write_text('',encoding='utf-8')
    (repo/'gzkit/probe.py').write_text(source,encoding='utf-8');(p/'outside.py').write_text('# outside\n',encoding='utf-8')
    (repo/'tests/probe.py').write_text('import unittest\nclass Probe(unittest.TestCase):\n'+test,encoding='utf-8')
    r=runner.execute(Path(sys.executable),repo,['tests.probe.Probe.test_probe'],p/'evidence','check',30,source_path='gzkit/probe.py',test_path='tests/probe.py')
    accepted=bool(r['assertion_failure'] and r['provenance_valid'] and not r['errors'] and not r['skipped'])
    report.append({'control':name,'expected_accepted':expected,'actual_accepted':accepted,'matches':accepted==expected,'detail':r})
(b/'provenance-controls-v2/results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps([{k:v for k,v in r.items() if k!='detail'} for r in report],indent=2))
assert all(r['matches'] for r in report)
