"""Rebind reviewed R16 fixture correction; preserve every exact mutation and selector."""
import ast,hashlib,json,sys
from pathlib import Path
b=Path('/private/tmp/gzkit-obpi04-final-mutations');root=Path('/Users/jeff/Documents/Code/gzkit')
sys.path.insert(0,str(b))
from build_manifest import build
old=json.loads((b/'manifest43-v3.json').read_text(encoding='utf-8'));new=build(root)
reviews=[]
for a,c in zip(old['cases'][:36],new['cases'],strict=True):
    fields=[k for k in c if c[k]!=a[k]]
    assert set(fields)<={'test_sha256'},(c['id'],fields)
    reviews.append({'id':c['id'],'changes':fields,'meaning':'same exact mutation and test selector; R16 fixture now seeds prior snapshot and checks replacement with current source bytes'})
for c in old['cases'][36:]:
    assert hashlib.sha256((root/c['path']).read_bytes()).hexdigest()==c['source_sha256']
    assert hashlib.sha256((root/c['test_path']).read_bytes()).hexdigest()==c['test_sha256']
    source=(root/c['path']).read_text(encoding='utf-8')
    nodes=[n for n in ast.walk(ast.parse(source)) if isinstance(n,ast.FunctionDef) and n.name==c['function']]
    assert len(nodes)==1 and ast.get_source_segment(source,nodes[0]).count(c['before'])==1
    new['cases'].append(c)
new['limitations']=old['limitations'];new['windows_status']=old['windows_status']
(b/'manifest43-v4.json').write_text(json.dumps(new,indent=2)+'\n',encoding='utf-8')
(b/'case-rebinding-review-v4.json').write_text(json.dumps(reviews,indent=2)+'\n',encoding='utf-8')
