import unittest
class Probe(unittest.TestCase):
    def setUp(self):
        raise RuntimeError("setup")
    def test_probe(self):
        pass
