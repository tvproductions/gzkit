import unittest
class Probe(unittest.TestCase):
    def helper(self):
        with self.subTest(case=1):
            self.assertEqual(1,2)
    def test_probe(self):
        self.helper()
