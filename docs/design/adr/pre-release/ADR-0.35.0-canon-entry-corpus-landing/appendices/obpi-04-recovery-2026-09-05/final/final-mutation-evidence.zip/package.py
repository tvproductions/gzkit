"""Retain all execution evidence and executed project bytes without duplicate checkouts."""
import hashlib,json,zipfile
from pathlib import Path
b=Path('/private/tmp/gzkit-obpi04-final-mutations')
files={p.relative_to(b).as_posix():p for p in b.iterdir() if p.is_file() and p.suffix in {'.py','.json','.md','.txt'}}
for name in ('full-run-v3','full-run-v4'):
    run=b/name
    for p in run.rglob('*'):
        rel=p.relative_to(run)
        if p.is_file() and rel.parts[0] not in {'baseline','work'} and '__pycache__' not in rel.parts:
            files[p.relative_to(b).as_posix()]=p
    loaded=set()
    for p in (run/'cases').glob('*/baseline.provenance.json'):
        proof=json.loads(p.read_text(encoding='utf-8'))
        for phase in ('before','after'):
            for row in proof[phase]['loaded_modules'].values():
                if row['resolved_file']:
                    loaded.add(Path(row['resolved_file']).relative_to(run/'work'))
    loaded.update([Path('pyproject.toml'),Path('uv.lock')])
    for rel in loaded:
        p=run/'baseline'/rel
        files[p.relative_to(b).as_posix()]=p
for p in (b/'provenance-controls-v2').rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:
        files[p.relative_to(b).as_posix()]=p
manifest={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in sorted(files.items())}
(b/'archive-members.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
files['archive-members.json']=b/'archive-members.json'
zpath=b/'final-mutation-evidence.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in sorted(files.items()): z.write(p,name)
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    for name,p in files.items(): assert z.read(name)==p.read_bytes(),name
report={'members':len(files),'verified_members':len(files),'byte_exact':True,'archive_bytes':zpath.stat().st_size,'archive_sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'omitted':'duplicate complete baseline/worktree copies and bytecode caches; executed project source modules, full inventories, and every output retained'}
(b/'archive-verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
