from pathlib import Path
__file__ = str(Path(__file__).resolve().parents[2] / "outside.py")
