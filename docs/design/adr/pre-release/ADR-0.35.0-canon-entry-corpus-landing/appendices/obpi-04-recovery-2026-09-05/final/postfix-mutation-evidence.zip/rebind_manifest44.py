"""Rebind manifest43-v4 to the post-round-12 bytes and add W08, the saved-error control.

Every existing case keeps its exact function-scoped edit and test selector; only
the two moved file hashes change. W08 is the one new control: it targets the
round-12 correction itself and nothing else. No historical guard is recovered.
"""
import ast
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path("/Users/jeff/Documents/Code/gzkit")
HERE = Path(__file__).resolve().parent
old = json.loads((HERE / "manifest43-v4.json").read_text(encoding="utf-8"))
new = json.loads(json.dumps(old))

def sha(path: str) -> str:
    return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()

sources: dict[str, ast.Module] = {}
def scope_count(path: str, function: str, needle: str) -> int:
    text = (ROOT / path).read_text(encoding="utf-8")
    tree = sources.setdefault(path, ast.parse(text))
    found = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == function]
    assert len(found) == 1, (path, function, len(found))
    return ast.get_source_segment(text, found[0]).count(needle)

def test_exists(test_path: str, selector: str) -> bool:
    text = (ROOT / test_path).read_text(encoding="utf-8")
    name = selector.rsplit(".", 1)[1]
    return any(isinstance(n, ast.FunctionDef) and n.name == name for n in ast.walk(ast.parse(text)))

review = []
for case in new["cases"]:
    changed = []
    for key, path_key in (("source_sha256", "path"), ("test_sha256", "test_path")):
        current = sha(case[path_key])
        if case[key] != current:
            changed.append(key)
            case[key] = current
    assert scope_count(case["path"], case["function"], case["before"]) == case["expected_scope_occurrences"], case["id"]
    for selector in case["tests"]:
        assert test_exists(case["test_path"], selector), (case["id"], selector)
    review.append({"id": case["id"], "classification": "same exact function-scoped edit and test selector; revalidated on post-round-12 AST", "changed_metadata": changed})

w08 = {
    "id": "W08",
    "subject": "Native failure paths report the saved callee error code, not a stale live read",
    "kind": "mocked-native-control",
    "historical_label": None,
    "historical_equivalence": None,
    "path": "src/gzkit/content/ownership.py",
    "function": "_windows_directory_error",
    "before": 'code = getattr(ctypes, "get_last_error")()  # noqa: B009 - platform-conditional ctypes API',
    "after": "code = None",
    "expected_scope_occurrences": 1,
    "source_sha256": sha("src/gzkit/content/ownership.py"),
    "tests": ["tests.content.test_ownership.TestWindowsDirectoryBarrier.test_native_failures_report_the_callee_error_code_not_a_stale_read"],
    "test_path": "tests/content/test_ownership.py",
    "test_sha256": sha("tests/content/test_ownership.py"),
    "require_assertion_failure": True,
    "native_runtime_proof": False,
}
assert scope_count(w08["path"], w08["function"], w08["before"]) == 1
assert test_exists(w08["test_path"], w08["tests"][0])
new["cases"].append(w08)
new["limitations"][-1] = new["limitations"][-1].replace("W01–W07", "W01–W08")
new["limitations"].append("W08 is the single post-round-12 addition: it deletes the saved-last-error read the round-12 medium finding introduced and is caught by that finding's regression test. The deterministic NATIVE failure-path witness for the same behavior runs only on Windows CI, not in this sweep.")
(HERE / "manifest44-v5.json").write_text(json.dumps(new, indent=2) + "\n", encoding="utf-8")
(HERE / "case-rebinding-review-v5.json").write_text(json.dumps(review, indent=2) + "\n", encoding="utf-8")
moved = sorted({k for r in review for k in r["changed_metadata"]})
print(json.dumps({"cases": len(new["cases"]), "rebound_keys": moved, "rebound_cases": sum(1 for r in review if r["changed_metadata"]), "hashes": {p: sha(p) for p in sorted({c["path"] for c in new["cases"]} | {c["test_path"] for c in new["cases"]})}}, indent=2))
