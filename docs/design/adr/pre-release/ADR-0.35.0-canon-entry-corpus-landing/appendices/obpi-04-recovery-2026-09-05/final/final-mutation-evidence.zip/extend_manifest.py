"""Preserve reconstructed case meanings and add six explicitly mocked native controls."""
import ast
import hashlib
import json
from pathlib import Path

BASE = Path('/private/tmp/gzkit-obpi04-final-mutations')
ROOT = Path('/Users/jeff/Documents/Code/gzkit')
old = json.loads(Path('/private/tmp/gzkit-obpi04-assessment-4dt92ti0/mutation-sweep/manifest.json').read_text(encoding='utf-8'))
new = json.loads((BASE / 'manifest-original36-v1.json').read_text(encoding='utf-8'))
comparison = []
for earlier, current in zip(old['cases'], new['cases'], strict=True):
    changed = [key for key in current if current[key] != earlier[key]]
    assert set(changed) <= {'source_sha256', 'test_sha256'}, (current['id'], changed)
    comparison.append({'id': current['id'], 'classification': 'same exact function-scoped edit and test selector; revalidated on current AST', 'changed_metadata': changed})
source_path = 'src/gzkit/content/ownership.py'
test_path = 'tests/content/test_ownership.py'
source = (ROOT / source_path).read_text(encoding='utf-8')
tests = (ROOT / test_path).read_text(encoding='utf-8')
source_ast, test_ast = ast.parse(source), ast.parse(tests)
def scope(function):
    found = [n for n in ast.walk(source_ast) if isinstance(n, ast.FunctionDef) and n.name == function]
    assert len(found) == 1
    return ast.get_source_segment(source, found[0])
pending_source = scope('_commit_windows_directory')
pending_start = pending_source.index('        if status == 0x103:')
pending_end = pending_source.index('        if status != 0:')
controls = [
    ('W01', 'Windows unavailable barrier must refuse', 'commit_directory_entry', '_commit_windows_directory(directory)', 'pass', 'test_unavailable_windows_barrier_refuses_instead_of_returning_success'),
    ('W02', 'Native flush warnings and errors must refuse', '_commit_windows_directory', 'if status != 0:', 'if False:', 'test_flush_errors_and_warnings_refuse_and_close_the_owned_handle'),
    ('W03', 'Pending native flush must complete before success', '_commit_windows_directory', pending_source[pending_start:pending_end], '        if status == 0x103:\n            status = 0\n', 'test_pending_flush_waits_then_checks_the_completion_status'),
    ('W04', 'Owned handle close failure must be observable', '_commit_windows_directory', 'if not kernel32.CloseHandle(handle):', 'if not kernel32.CloseHandle(handle) and False:', 'test_close_failure_is_observable_even_after_a_completed_flush'),
    ('W05', 'Native NTSTATUS ABI stays 32 bits', '_windows_directory_apis', 'ntdll.NtFlushBuffersFileEx.restype = ctypes.c_int32', 'ntdll.NtFlushBuffersFileEx.restype = ctypes.c_int64', 'test_native_abi_uses_windows_widths_and_pointer_alignment_on_every_host'),
    ('W06', 'Unknown platform has no successful no-op', 'commit_directory_entry', 'raise OSError(errno.ENOTSUP, "directory synchronization is unsupported", str(directory))', 'return', 'test_unknown_platform_has_no_successful_no_op'),
]
for identifier, subject, function, before, after, test in controls:
    assert scope(function).count(before) == 1, identifier
    matches = [n for n in ast.walk(test_ast) if isinstance(n, ast.FunctionDef) and n.name == test]
    assert len(matches) == 1, (identifier, test)
    new['cases'].append({'id': identifier, 'subject': subject, 'kind': 'mocked-native-control', 'historical_label': None, 'historical_equivalence': None, 'path': source_path, 'function': function, 'before': before, 'after': after, 'expected_scope_occurrences': 1, 'source_sha256': hashlib.sha256((ROOT/source_path).read_bytes()).hexdigest(), 'tests': ['tests.content.test_ownership.TestWindowsDirectoryBarrier.'+test], 'test_path': test_path, 'test_sha256': hashlib.sha256((ROOT/test_path).read_bytes()).hexdigest(), 'require_assertion_failure': True, 'native_runtime_proof': False})
new['limitations'][-1] = 'W01–W06 exercise production native routing/status/ABI logic with mocked OS boundaries on the local host. They do not establish actual Windows runtime behavior; native integration evidence is separate.'
new['windows_status'] = 'MOCKED_NATIVE_CONTROLS_INCLUDED; REAL_WINDOWS_INTEGRATION_SEPARATE'
(BASE / 'case-rebinding-review-v1.json').write_text(json.dumps(comparison, indent=2)+'\n', encoding='utf-8')
(BASE / 'manifest42-v1.json').write_text(json.dumps(new, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'original_meanings_unchanged':len(comparison),'new_mocked_controls':len(controls),'hashes': {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in {c['path'] for c in new['cases']}|{c['test_path'] for c in new['cases']}}},indent=2))
