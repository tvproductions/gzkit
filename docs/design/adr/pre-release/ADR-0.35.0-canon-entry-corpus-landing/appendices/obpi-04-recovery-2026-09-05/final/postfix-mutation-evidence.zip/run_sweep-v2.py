"""Run exact mutations only in a retained isolated snapshot, never the checkout."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

BOOTSTRAP = r"""
import hashlib
import importlib
import json
import sys
import traceback
import unittest
from pathlib import Path

config = json.loads(sys.argv[1])
repo = Path(config["repo"]).resolve(strict=True)
proof_path = Path(config["provenance_path"])
proof = {"verified": False, "before": {}, "after": {}, "execution": None}


def persist():
    proof_path.write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")


def origins():
    loaded = {}
    violations = []
    for name, module in sorted(sys.modules.copy().items()):
        if not (name in {"gzkit", "tests"} or name.startswith(("gzkit.", "tests."))):
            continue
        filename = getattr(module, "__file__", None)
        search_paths = list(getattr(module, "__path__", ()))
        row = {"__file__": filename, "resolved_file": None, "namespace_paths": []}
        if filename:
            resolved = Path(filename).resolve(strict=True)
            row["resolved_file"] = str(resolved)
            if not resolved.is_relative_to(repo):
                violations.append(f"{name} loaded from outside isolated work: {resolved}")
        elif search_paths:
            row["namespace_paths"] = [str(Path(p).resolve(strict=True)) for p in search_paths]
            if not all(Path(p).is_relative_to(repo) for p in row["namespace_paths"]):
                violations.append(f"{name} has namespace paths outside isolated work")
        else:
            violations.append(f"{name} has no inspectable file or namespace origin")
        loaded[name] = row
    for name, expected in config["targets"].items():
        row = loaded.get(name)
        if row is None or row["resolved_file"] != expected["path"]:
            violations.append(f"Target {name} did not load the expected isolated file")
        elif (
            hashlib.sha256(Path(row["resolved_file"]).read_bytes()).hexdigest()
            != expected["sha256"]
        ):
            violations.append(f"Target {name} changed bytes during execution")
    return {"loaded_modules": loaded, "violations": violations}


# A helper subTest captures its traceback before unwinding to the selected
# method. Record execution phase as well; setup/teardown never arm this flag.
_active_test_method = None
_original_call_test_method = unittest.TestCase._callTestMethod


def _call_selected_method(self, method):
    global _active_test_method
    previous = _active_test_method
    _active_test_method = (id(self), getattr(method, "__code__", None))
    try:
        return _original_call_test_method(self, method)
    finally:
        _active_test_method = previous


unittest.TestCase._callTestMethod = _call_selected_method


class EvidenceResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.assertion_evidence = []

    def note_failure(self, test, err):
        method = getattr(test, getattr(test, "_testMethodName", ""), None)
        code = getattr(method, "__code__", None)
        tb = err[2]
        reached = False
        while tb is not None:
            reached = reached or (code is not None and tb.tb_frame.f_code is code)
            tb = tb.tb_next
        self.assertion_evidence.append({
            "test_id": test.id(),
            "exception_type": type(err[1]).__name__,
            "assertion_error": isinstance(err[1], AssertionError),
            "test_method_reached": reached or _active_test_method == (id(test), code),
            "test_method_in_traceback": reached,
            "test_method_active_at_subtest_failure": _active_test_method == (id(test), code),
        })

    def addFailure(self, test, err):
        self.note_failure(test, err)
        super().addFailure(test, err)

    def addSubTest(self, test, subtest, err):
        if err is not None and issubclass(err[0], test.failureException):
            self.note_failure(test, err)
        super().addSubTest(test, subtest, err)


try:
    for name in config["targets"]:
        importlib.import_module(name)
    suite = unittest.defaultTestLoader.loadTestsFromNames(config["tests"])
    proof["before"] = origins()
    persist()
    if proof["before"]["violations"]:
        raise RuntimeError("Import provenance failed before tests")
    result = unittest.TextTestRunner(verbosity=2, resultclass=EvidenceResult).run(suite)
    proof["execution"] = {
        "tests_run": result.testsRun,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "successful": result.wasSuccessful(),
        "assertion_evidence": result.assertion_evidence,
    }
    proof["after"] = origins()
    proof["verified"] = not proof["after"]["violations"]
    persist()
    if not proof["verified"]:
        raise RuntimeError("Import provenance failed after tests")
except Exception as exc:
    proof["verified"] = False
    proof["bootstrap_error"] = f"{type(exc).__name__}: {exc}"
    persist()
    traceback.print_exc()
    raise SystemExit(86)
raise SystemExit(0 if result.wasSuccessful() else 1)
"""


def sha(data: bytes) -> str:
    """Hash exact bytes without decoding or normalizing them."""
    return hashlib.sha256(data).hexdigest()


def inventory(root: Path) -> dict[str, str]:
    """Hash every non-bytecode file in a retained snapshot."""
    return {
        str(path.relative_to(root)): sha(path.read_bytes())
        for path in sorted(root.rglob("*"))
        if path.is_file() and "__pycache__" not in path.parts
    }


def snapshot(source: Path, destination: Path) -> dict:
    """Copy tracked inputs including dirty versions; never copy cache or .git."""
    result = subprocess.run(
        ["git", "ls-files", "-z"],
        cwd=source,
        capture_output=True,
        check=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    excluded = {".git", ".venv", "__pycache__", ".pytest_cache", ".ruff_cache", ".codex"}
    paths = [Path(path) for path in result.stdout.split("\0") if path]
    for relative in paths:
        path = source / relative
        if excluded.intersection(relative.parts) or not path.is_file():
            continue
        if path.is_symlink():
            raise RuntimeError(
                f"Snapshot must not follow a symlink outside its provenance: {relative}"
            )
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
    return inventory(destination)


def mutate(source: str, case: dict) -> str:
    """Apply the one manifest edit within its uniquely named function."""
    nodes = [
        node
        for node in ast.walk(ast.parse(source))
        if isinstance(node, ast.FunctionDef) and node.name == case["function"]
    ]
    if len(nodes) != 1:
        raise ValueError(f"Expected exactly one function {case['function']}, found {len(nodes)}")
    node = nodes[0]
    lines = source.splitlines(keepends=True)
    start, end = sum(map(len, lines[: node.lineno - 1])), sum(map(len, lines[: node.end_lineno]))
    scope = source[start:end]
    count = scope.count(case["before"])
    if count != case["expected_scope_occurrences"]:
        raise ValueError(f"Expected exact mutation target count 1, found {count}")
    changed = source[:start] + scope.replace(case["before"], case["after"], 1) + source[end:]
    if changed == source:
        raise ValueError("Mutation left source unchanged")
    ast.parse(changed)
    return changed


def execute(
    python: Path,
    repo: Path,
    tests: list[str],
    directory: Path,
    phase: str,
    timeout: int,
    *,
    source_path: str,
    test_path: str,
) -> dict:
    """Run a fresh interpreter and retain import and unittest evidence."""
    directory.mkdir(parents=True, exist_ok=True)
    targets = {}
    for relative in (source_path, test_path):
        path = (repo / relative).resolve(strict=True)
        module = ".".join(Path(relative.removeprefix("src/")).with_suffix("").parts)
        targets[module] = {"path": str(path), "sha256": sha(path.read_bytes())}
    provenance_path = directory / f"{phase}.provenance.json"
    config = {
        "repo": str(repo.resolve()),
        "tests": tests,
        "targets": targets,
        "provenance_path": str(provenance_path.resolve()),
    }
    command = [str(python), "-B", "-c", BOOTSTRAP, json.dumps(config)]
    environment = dict(os.environ)
    environment.update(
        {
            "PYTHONPATH": f"{repo / 'src'}{os.pathsep}{repo}",
            "PYTHONIOENCODING": "utf-8",
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONPYCACHEPREFIX": str(directory / f"pycache-{phase}"),
            "UV_CACHE_DIR": "/tmp/gzkit-health-uv-cache",
            "UV_TOOL_DIR": "/tmp/gzkit-health-uv-tools",
        }
    )
    # A -B interpreter can still read old bytecode; snapshots exclude all caches,
    # and each subprocess has a fresh empty prefix as a second safeguard.
    start = time.monotonic()
    try:
        process = subprocess.run(
            command,
            cwd=repo,
            env=environment,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
        code, stdout, stderr, timed_out = process.returncode, process.stdout, process.stderr, False
    except subprocess.TimeoutExpired as exc:
        code, timed_out = None, True
        stdout = (
            exc.stdout.decode("utf-8", errors="replace")
            if isinstance(exc.stdout, bytes)
            else exc.stdout or ""
        )
        stderr = (
            exc.stderr.decode("utf-8", errors="replace")
            if isinstance(exc.stderr, bytes)
            else exc.stderr or ""
        )
    (directory / f"{phase}.stdout").write_text(stdout, encoding="utf-8")
    (directory / f"{phase}.stderr").write_text(stderr, encoding="utf-8")
    try:
        provenance = json.loads(provenance_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        provenance = {}
    execution = provenance.get("execution") or {}
    assertion_evidence = execution.get("assertion_evidence", [])
    result = {
        "command": command,
        "cwd": str(repo),
        "environment_overrides": {
            key: environment[key]
            for key in (
                "PYTHONPATH",
                "PYTHONIOENCODING",
                "PYTHONDONTWRITEBYTECODE",
                "PYTHONPYCACHEPREFIX",
                "UV_CACHE_DIR",
                "UV_TOOL_DIR",
            )
        },
        "returncode": code,
        "timed_out": timed_out,
        "elapsed_seconds": round(time.monotonic() - start, 3),
        "tests_run": execution.get("tests_run", 0),
        "failures": execution.get("failures", 0),
        "errors": execution.get("errors", 0),
        "assertion_failure": bool(assertion_evidence)
        and all(
            row["assertion_error"] and row["test_method_reached"] for row in assertion_evidence
        ),
        "skipped": bool(execution.get("skipped", 0)),
        "provenance_valid": provenance.get("verified") is True,
        "provenance_path": str(provenance_path),
        "stdout_path": str(directory / f"{phase}.stdout"),
        "stderr_path": str(directory / f"{phase}.stderr"),
    }
    (directory / f"{phase}.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def main() -> int:
    """Validate inputs, witness selected mutations, and restore exact bytes."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--cases",
        help="Comma-separated explicit case IDs; omission selects the whole current manifest",
    )
    parser.add_argument("--timeout", type=int, default=120)
    args = parser.parse_args()
    root = args.root.resolve()
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    source_commit = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=root,
        capture_output=True,
        check=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    ).stdout.strip()
    selected = (
        set(args.cases.split(",")) if args.cases else {case["id"] for case in manifest["cases"]}
    )
    cases = [case for case in manifest["cases"] if case["id"] in selected]
    if len(cases) != len(selected):
        raise ValueError("Unknown case ID; selection must match exact manifest IDs")
    if args.output.exists():
        raise ValueError("Output directory already exists; evidence is never overwritten")
    output = args.output.resolve()
    if output == root or root in output.parents:
        raise ValueError("Evidence and mutations must live outside the live checkout")
    for case in cases:
        if sha((root / case["path"]).read_bytes()) != case["source_sha256"]:
            raise ValueError(
                f"Source drift for {case['id']}; rebuild a manifest, do not silently retarget"
            )
        if sha((root / case["test_path"]).read_bytes()) != case["test_sha256"]:
            raise ValueError(f"Test drift for {case['id']}; rebuild a manifest")
    output.mkdir(parents=True)
    shutil.copy2(args.manifest, output / "manifest.json")
    baseline, working = output / "baseline", output / "work"
    initial = snapshot(root, baseline)
    for case in cases:
        for key, digest in (("path", "source_sha256"), ("test_path", "test_sha256")):
            if sha((baseline / case[key]).read_bytes()) != case[digest]:
                raise ValueError(f"Input changed during snapshot for {case['id']}: {case[key]}")
    # This remains an unmodified byte-for-byte baseline beside a disposable working tree.
    shutil.copytree(baseline, working)
    (output / "baseline-sha256.json").write_text(
        json.dumps(initial, indent=2) + "\n", encoding="utf-8"
    )
    python = Path(sys.executable)
    result = {
        "started_at": datetime.now(UTC).isoformat(),
        "manifest_sha256": sha(args.manifest.read_bytes()),
        "runner_sha256": sha(Path(__file__).read_bytes()),
        "selected": sorted(selected),
        "source_root": str(root),
        "source_commit": source_commit,
        "committed_input_sha256": {
            path: sha(
                subprocess.run(
                    ["git", "show", f"{source_commit}:{path}"],
                    cwd=root,
                    capture_output=True,
                    check=True,
                ).stdout
            )
            for path in sorted({case[key] for case in cases for key in ("path", "test_path")})
        },
        "baseline": str(baseline),
        "work": str(working),
        "limits": manifest["limitations"],
        "windows_status": manifest["windows_status"],
        "cases": [],
    }
    result["inputs_match_source_commit"] = all(
        initial[path] == digest for path, digest in result["committed_input_sha256"].items()
    )
    for case in cases:
        directory = output / "cases" / case["id"]
        path = working / case["path"]
        original = path.read_bytes()
        entry = {
            "id": case["id"],
            "subject": case["subject"],
            "kind": case["kind"],
            "original_sha256": sha(original),
        }
        try:
            green = execute(
                python,
                working,
                case["tests"],
                directory,
                "baseline",
                args.timeout,
                source_path=case["path"],
                test_path=case["test_path"],
            )
            entry["baseline"] = green
            if (
                green["returncode"] != 0
                or not green["tests_run"]
                or green["skipped"]
                or not green["provenance_valid"]
            ):
                entry["status"] = "BASELINE_INVALID"
            else:
                changed = mutate(original.decode("utf-8"), case).encode("utf-8")
                (directory / "mutation.before").write_bytes(original)
                (directory / "mutation.after").write_bytes(changed)
                path.write_bytes(changed)
                entry["mutated_sha256"] = sha(changed)
                red = execute(
                    python,
                    working,
                    case["tests"],
                    directory,
                    "mutant",
                    args.timeout,
                    source_path=case["path"],
                    test_path=case["test_path"],
                )
                entry["mutant"] = red
                if not red["provenance_valid"]:
                    entry["status"] = "INVALID_RED"
                elif red["returncode"] == 0:
                    entry["status"] = "SURVIVED"
                elif red["timed_out"] or red["errors"] or not red["tests_run"] or red["skipped"]:
                    entry["status"] = "INVALID_RED"
                elif red["failures"] and red["assertion_failure"]:
                    entry["status"] = "KILLED"
                else:
                    entry["status"] = "INVALID_RED"
        except Exception as exc:  # noqa: BLE001 - record harness faults and always restore
            entry.update(status="HARNESS_ERROR", exception=f"{type(exc).__name__}: {exc}")
        finally:
            path.write_bytes(original)
            entry["restored_sha256"] = sha(path.read_bytes())
            entry["restored"] = (
                path.read_bytes() == original == (baseline / case["path"]).read_bytes()
            )
            if not entry["restored"]:
                entry["status"] = "RESTORATION_FAILED"
            result["cases"].append(entry)
            (output / "results.json").write_text(
                json.dumps(result, indent=2) + "\n", encoding="utf-8"
            )
            print(f"{case['id']}: {entry['status']} (restored={entry['restored']})", flush=True)
    final = inventory(baseline)
    result["baseline_unchanged"] = initial == final
    result["ended_at"] = datetime.now(UTC).isoformat()
    result["selected_cases_witnessed"] = (
        all(case["status"] == "KILLED" for case in result["cases"]) and result["baseline_unchanged"]
    )
    result["full_manifest_selected"] = len(cases) == len(manifest["cases"])
    result["obpi_sweep_complete"] = False  # Native Windows cases remain explicitly pending.
    (output / "results.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(
        json.dumps(
            {
                key: result[key]
                for key in (
                    "selected_cases_witnessed",
                    "baseline_unchanged",
                    "full_manifest_selected",
                    "obpi_sweep_complete",
                )
            }
        )
    )
    return 0 if result["selected_cases_witnessed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
