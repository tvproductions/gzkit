"""Add the reviewer-demonstrated flags-strength negative control, without changing v1."""
import ast
import json
from pathlib import Path
base = Path('/private/tmp/gzkit-obpi04-final-mutations')
root = Path('/Users/jeff/Documents/Code/gzkit')
manifest = json.loads((base/'manifest42-v1.json').read_text(encoding='utf-8'))
case = dict(next(c for c in manifest['cases'] if c['id']=='W02'))
case.update(id='W07',subject='Native flush requests synchronization rather than NO_SYNC',before='ntdll.NtFlushBuffersFileEx(handle, 0, None, 0, ctypes.byref(status_block))',after='ntdll.NtFlushBuffersFileEx(handle, 2, None, 0, ctypes.byref(status_block))',tests=['tests.content.test_ownership.TestWindowsDirectoryBarrier.test_native_flush_requests_metadata_and_storage_synchronization'])
source = (root/case['path']).read_text(encoding='utf-8')
node = next(n for n in ast.walk(ast.parse(source)) if isinstance(n,ast.FunctionDef) and n.name==case['function'])
assert ast.get_source_segment(source,node).count(case['before']) == 1
assert any(isinstance(n,ast.FunctionDef) and n.name==case['tests'][0].rsplit('.',1)[1] for n in ast.walk(ast.parse((root/case['test_path']).read_text(encoding='utf-8'))))
manifest['cases'].append(case)
manifest['limitations'][-1] = manifest['limitations'][-1].replace('W01–W06','W01–W07')
(base/'manifest43-v2.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('43 exact cases: original36 + mocked native7')
