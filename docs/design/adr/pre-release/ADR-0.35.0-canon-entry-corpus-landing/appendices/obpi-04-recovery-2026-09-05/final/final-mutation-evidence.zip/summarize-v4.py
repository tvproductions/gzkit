"""Summarize retained results and check whether live selected input still matches."""
import hashlib,json
from collections import Counter
from pathlib import Path
b=Path('/private/tmp/gzkit-obpi04-final-mutations'); root=Path('/Users/jeff/Documents/Code/gzkit')
m=json.loads((b/'manifest43-v4.json').read_text(encoding='utf-8')); r=json.loads((b/'full-run-v4/results.json').read_text(encoding='utf-8'))
expected={}
for c in m['cases']:
    for p,h in [('path','source_sha256'),('test_path','test_sha256')]:
        if c[p] in expected: assert expected[c[p]]==c[h]
        expected[c[p]]=c[h]
actual={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in expected}
summary={'source_commit':r['source_commit'],'source_hashes':expected,'live_hashes_after_run':actual,'live_inputs_still_match':expected==actual,'counts':dict(Counter(c['status'] for c in r['cases'])),'cases':len(r['cases']),'original36':dict(Counter(c['status'] for c in r['cases'] if not c['id'].startswith('W'))),'mocked_native7':dict(Counter(c['status'] for c in r['cases'] if c['id'].startswith('W'))),'passing_unskipped_baselines':sum(c['baseline']['returncode']==0 and not c['baseline']['skipped'] for c in r['cases']),'all_provenance_valid':all(c['baseline']['provenance_valid'] and c.get('mutant',{}).get('provenance_valid') for c in r['cases']),'all_exact_restorations':all(c['restored'] for c in r['cases']),'baseline_unchanged':r['baseline_unchanged'],'full_manifest_selected':r['full_manifest_selected'],'obpi_sweep_complete':r['obpi_sweep_complete'],'manifest_sha256':r['manifest_sha256'],'runner_sha256':r['runner_sha256'],'started_at':r['started_at'],'ended_at':r['ended_at'],'boundaries':['G1–G18 are reconstructed exact current edits; historical runner lost.','Historical G19–G22 remain missing. R01–R18 and W01–W07 do not replace them.','W01–W07 mock native calls/ABI and do not establish actual Windows runtime behavior.','No physical power-loss proof, exhaustive fault coverage, or OBPI completion claimed.']}
(b/'summary-v4.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
